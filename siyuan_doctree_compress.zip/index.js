"use strict";var j=Object.defineProperty;var A=(c,i,e)=>i in c?j(c,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):c[i]=e;var p=(c,i,e)=>(A(c,typeof i!="symbol"?i+"":i,e),e);const R=require("siyuan");class q{constructor(i,e,t,s,n){p(this,"plugin");p(this,"name");p(this,"file");p(this,"settings",new Map);p(this,"elements",new Map);this.name=e??"settings",this.plugin=i,this.file=this.name.endsWith(".json")?this.name:`${this.name}.json`,this.plugin.setting=new R.Setting({width:s,height:n,confirmCallback:()=>{for(let r of this.settings.keys())this.updateValue(r);let a=this.dump();t!==void 0?t(a):(this.plugin.data[this.name]=a,this.save()),window.location.reload()}})}async load(){let i=await this.plugin.loadData(this.file);if(console.debug("Load config:",i),i)for(let[e,t]of this.settings)t.value=(i==null?void 0:i[e])??t.value;return this.plugin.data[this.name]=this.dump(),i}async save(){let i=this.dump();return await this.plugin.saveData(this.file,this.dump()),i}get(i){var e;return(e=this.settings.get(i))==null?void 0:e.value}async assignValue(i,e){let t=this.settings.get(i);t.value=e,this.plugin.data[this.name]=t.value,await this.save(),window.location.reload()}dump(){let i={};for(let[e,t]of this.settings)t.type!=="button"&&(i[e]=t.value);return i}addItem(i){var t,s,n,a,r;this.settings.set(i.key,i);let e;switch(i.type){case"checkbox":let l=document.createElement("input");l.type="checkbox",l.checked=i.value,l.className="b3-switch fn__flex-center",e=l;break;case"select":let d=document.createElement("select");d.className="b3-select fn__flex-center fn__size200";let f=(i==null?void 0:i.options)??{};for(let _ in f){let g=document.createElement("option"),x=f[_];g.value=_,g.text=x,d.appendChild(g)}d.value=i.value,e=d;break;case"slider":let o=document.createElement("input");o.type="range",o.className="b3-slider fn__size200 b3-tooltips b3-tooltips__n",o.ariaLabel=i.value,o.min=((t=i.slider)==null?void 0:t.min.toString())??"0",o.max=((s=i.slider)==null?void 0:s.max.toString())??"100",o.step=((n=i.slider)==null?void 0:n.step.toString())??"1",o.value=i.value,o.onchange=()=>{o.ariaLabel=o.value},e=o;break;case"textinput":let m=document.createElement("input");m.className="b3-text-field fn__flex-center fn__size200",m.value=i.value,e=m;break;case"textarea":let v=document.createElement("textarea");v.className="b3-text-field fn__block",v.value=i.value,e=v;break;case"number":let h=document.createElement("input");h.type="number",h.className="b3-text-field fn__flex-center fn__size200",h.value=i.value,e=h;break;case"button":let u=document.createElement("button");u.className="b3-button b3-button--outline fn__flex-center fn__size200",u.innerText=((a=i.button)==null?void 0:a.label)??"Button",u.onclick=((r=i.button)==null?void 0:r.callback)??(()=>{}),e=u;break;case"hint":let y=document.createElement("div");y.className="b3-label fn__flex-center",e=y;break}this.elements.set(i.key,e),this.plugin.setting.addItem({title:i.title,description:i==null?void 0:i.description,createActionElement:()=>this.getElement(i.key)})}getElement(i){let e=this.settings.get(i),t=this.elements.get(i);switch(e.type){case"checkbox":t.checked=e.value;break;case"select":t.value=e.value;break;case"slider":t.value=e.value,t.ariaLabel=e.value;break;case"textinput":t.value=e.value;break;case"textarea":t.value=e.value;break}return t}updateValue(i){let e=this.settings.get(i),t=this.elements.get(i);switch(e.type){case"checkbox":e.value=t.checked;break;case"select":e.value=t.value;break;case"slider":e.value=t.value;break;case"textinput":e.value=t.value;break;case"textarea":e.value=t.value;break}}}const S="menu-config";class V extends R.Plugin{constructor(){super(...arguments);p(this,"settingUtils")}disableDocumentButtonsPopup(){const e=`
        .b3-list-item__icon.b3-tooltips.b3-tooltips__n:hover::after,
        .b3-list-item__action.b3-tooltips.b3-tooltips__nw:hover::after,
        .popover__block.b3-tooltips.b3-tooltips__nw:hover::after {
          display: none;
        }                    
       `;this.applyStyles(e)}displayIconButDIsableIconClick(){const e=`
        .b3-list-item__icon.b3-tooltips.b3-tooltips__n[aria-label="修改图标"],
        .b3-list-item__icon.b3-tooltips.b3-tooltips__n[aria-label="Change icon"] {
        pointer-events: none;
        }
       `;this.applyStyles(e)}mouseOverReduceFontSize(e,t){const s=e?`
        .layout-tab-container .b3-list-item:hover > .b3-list-item__text {
            font-size: ${t}px !important;
         }
         `:`
         .layout-tab-container .b3-list-item:hover > .b3-list-item__text {
            font-size: ${t}px;
         }`;this.applyStyles(s)}mouseOverLineUnclamp(e){const t=e?`
        .layout-tab-container .b3-list-item:hover > .b3-list-item__text {
            overflow:visible !important;
         -webkit-line-clamp: unset;
         }
         `:`
         .layout-tab-container .b3-list-item:hover > .b3-list-item__text {
            overflow:visible;
         -webkit-line-clamp: unset;
         }`;this.applyStyles(t)}mouseOverZeroPadding(e,t){const s=e?`
        .layout-tab-container .b3-list-item:hover > .b3-list-item__toggle {
            padding-left: ${t}px !important;
        }
        `:`
        .layout-tab-container .b3-list-item:hover > .b3-list-item__toggle {
            padding-left: ${t}px;
        }`;this.applyStyles(s)}hideContextualLabel(){const e=`
        .fn__flex-1.fn__flex-column.file-tree.sy__file .ariaLabel:hover {
            pointer-events: none;
          }                      
       `;this.applyStyles(e)}overloadLineHeight(e,t){const s=e?`
        .layout-tab-container .b3-list-item__text {
            line-height: ${t}px !important;
         }
         `:`
         .layout-tab-container .b3-list-item__text {
            line-height: ${t}px;
         }`;this.applyStyles(s)}addFrontLine(e,t,s){t>=e&&(t=e);const n=`

        .layout-tab-container .b3-list-item > .b3-list-item__toggle {
            padding-left: 4px !important;
        }

        .layout-tab-container ul ul:before {
            content: "";
            position: absolute;
            top: 0;
            bottom: 0;
            left: ${e}px;
            border-left: ${s}px solid var(--b3-theme-background-light);
        }
        
        .layout-tab-container ul ul {
            position: relative;
            padding-left: ${t}px;
        }
        
        `;this.applyStyles(n)}addSeperateLine(e){const t=`
        .layout-tab-container .b3-list-item__text {
            border-top: ${e}px solid #eaecef;
        }
        `;this.applyStyles(t)}rmvDoctreeIcons(e){const t=e?`
            .b3-list-item__icon {
                display: none !important;
            }
            `:`
            .b3-list-item__icon {
                display: none;
            }
            `;this.applyStyles(t)}rmvdoctreeIcons(e){const t=".b3-list-item__icon",s=e==!0?`
            .${t} {
                display: none !important;
            }
        `:`
            .${t} {
                display: none;
            }
        `;this.applyStyles(s)}overloadDoctreeFontSize(e,t){const s=e==!0?`
        .layout-tab-container.fn__flex-1 {
            font-size: ${t}px !important;
        }
        `:`
        .layout-tab-container.fn__flex-1 {
            font-size: ${t}px;
        }
        `;this.applyStyles(s)}applyStyles(e){const t=document.head||document.getElementsByTagName("head")[0],s=document.createElement("style");t.appendChild(s),s.appendChild(document.createTextNode(e))}async appendCurrentDeviceIntoList(){try{var e=await this.fetchCurrentDeviceInfo(),t=this.settingUtils.get("enableDeviceList"),s=t.split(`
`),n=s.length,a=s[n-1];a===""&&s.pop(),s.push(e);var r=s.join(`
`);this.settingUtils.assignValue("enableDeviceList",r),this.settingUtils.save()}catch(l){console.error("Error appending current device into list:",l)}}async removeCurrentDeviceFromList(){try{for(var e=await this.fetchCurrentDeviceInfo(),t=this.settingUtils.get("enableDeviceList"),s=t.split(`
`),n=s.length-1;n>=0;n--){var a=s[n];a===e&&s.splice(n,1)}var r=s.join(`
`);this.settingUtils.assignValue("enableDeviceList",r),this.settingUtils.save()}catch(l){console.error("Error removing current device from list:",l)}}fetchCurrentDeviceInfo(){var e=window.siyuan.config.system.id,t=window.siyuan.config.system.name,s=e+" "+t;return Promise.resolve(s.toString())}async currentDeviceInList(){try{var e=await this.fetchCurrentDeviceInfo(),t=await this.settingUtils.get("enableDeviceList"),s=t.split(`
`);return s.includes(e)}catch(n){console.error("Error checking if current device is enabled:",n)}}async onload(){this.data[S]={readonlyText:"Readonly"},this.settingUtils=new q(this,S),this.settingUtils.load(),this.settingUtils.addItem({key:"mainSwitch",value:!1,type:"checkbox",title:this.i18n.mainSwitch,description:""}),this.settingUtils.addItem({key:"highPerformanceZoneHint",value:"",type:"hint",title:this.i18n.experimentFeatureHintTitle,description:this.i18n.experimentFeatureHintDesc}),this.settingUtils.addItem({key:"mouseHoverZeroPadding",value:!1,type:"checkbox",title:this.i18n.mouseHoverZeroPadding,description:this.i18n.mouseHoverZeroPaddingDesc}),this.settingUtils.addItem({key:"mouseHoverZeroPaddingForce",value:!0,type:"checkbox",title:this.i18n.mouseHoverZeroPaddingForce,description:this.i18n.mouseHoverZeroPaddingForceDesc}),this.settingUtils.addItem({key:"mouseHoverZeroPaddingPx",value:4,type:"slider",title:this.i18n.mouseHoverZeroPaddingPx,description:this.i18n.mouseHoverZeroPaddingPxDesc,slider:{min:0,max:10,step:1}}),this.settingUtils.addItem({key:"mouseOverLineUnclamp",value:!1,type:"checkbox",title:this.i18n.mouseOverLineUnclampTitle,description:this.i18n.mouseOverLineUnclampDesc}),this.settingUtils.addItem({key:"mouseOverLineUnclampForce",value:!1,type:"checkbox",title:this.i18n.mouseOverLineUnclampForceTitle,description:this.i18n.mouseOverLineUnclampForceDesc}),this.settingUtils.addItem({key:"mouseOverReduceFontSize",value:!1,type:"checkbox",title:this.i18n.mouseOverReduceFontSizeTitle,description:this.i18n.mouseOverReduceFontSizeDesc}),this.settingUtils.addItem({key:"mouseOverReduceFontSizeForce",value:!1,type:"checkbox",title:this.i18n.mouseOverReduceFontSizeForceTitle,description:this.i18n.mouseOverReduceFontSizeForceDesc}),this.settingUtils.addItem({key:"mouseHoverReduceFontSizePx",value:4,type:"slider",title:this.i18n.mouseHoverReduceFontSizePx,description:this.i18n.mouseHoverReduceFontSizePxDesc,slider:{min:1,max:50,step:1}}),this.settingUtils.addItem({key:"disable document buttons popup",value:!1,type:"checkbox",title:this.i18n.disableDocumentButtonsPopup,description:this.i18n.disableDocumentButtonsPopupDesc}),this.settingUtils.addItem({key:"hideContextualLabel",value:!1,type:"checkbox",title:this.i18n.hideContextualLabel,description:this.i18n.hideContextualLabelDesc}),this.settingUtils.addItem({key:"hintDangerousZone",value:"",type:"hint",title:this.i18n.hintDangerousZoneTitle,description:this.i18n.hintDangerousZoneDesc}),this.settingUtils.addItem({key:"enableAdjustStaticDoctreePadding",value:!1,type:"checkbox",title:this.i18n.enableAdjustStaticDoctreePadding,description:this.i18n.enableAdjustStaticDoctreePaddingDesc}),this.settingUtils.addItem({key:"Slider",value:50,type:"slider",title:this.i18n.compressPercent,description:this.i18n.compressPercentDesc,slider:{min:0,max:100,step:5}}),this.settingUtils.addItem({key:"enableDoctreeFrontLine",value:!1,type:"checkbox",title:this.i18n.enableDoctreeFrontLine,description:this.i18n.enableDoctreeFrontLineDesc}),this.settingUtils.addItem({key:"doctreeFrontLinePosition",value:20,type:"slider",title:this.i18n.doctreeFrontLinePosition,description:this.i18n.doctreeFrontLinePositionDesc,slider:{min:0,max:60,step:1}}),this.settingUtils.addItem({key:"doctreeFrontLinePadding",value:20,type:"slider",title:this.i18n.doctreeFrontLinePadding,description:this.i18n.doctreeFrontLinePaddingDesc,slider:{min:6,max:60,step:1}}),this.settingUtils.addItem({key:"doctreeFrontLineBorder",value:2,type:"slider",title:this.i18n.doctreeFrontLineBorder,description:this.i18n.doctreeFrontLineBorderDesc,slider:{min:1,max:20,step:1}}),this.settingUtils.addItem({key:"enableDoctreeSeperateLine",value:!1,type:"checkbox",title:this.i18n.enableDoctreeSeperateLine,description:this.i18n.enableDoctreeSeperateLineDesc}),this.settingUtils.addItem({key:"doctreeSeperateLineBorder",value:2,type:"slider",title:this.i18n.doctreeSeperateLineBorder,description:this.i18n.doctreeSeperateLineBorderDesc,slider:{min:1,max:20,step:1}}),this.settingUtils.addItem({key:"hideIcon",value:!1,type:"checkbox",title:this.i18n.hideIcon,description:this.i18n.hideIconDesc}),this.settingUtils.addItem({key:"hideIconForce",value:!1,type:"checkbox",title:this.i18n.hideIconForce,description:this.i18n.hideIconDescForce}),this.settingUtils.addItem({key:"displayIconButDisableIconClick",value:!1,type:"checkbox",title:this.i18n.displayIconButDisableIconClick,description:this.i18n.displayIconButDisableIconClickDesc}),this.settingUtils.addItem({key:"overloadFontSizeSwitch",value:!1,type:"checkbox",title:this.i18n.overloadFontSizeSwitch,description:this.i18n.overloadFontSizeSwitchDesc}),this.settingUtils.addItem({key:"overloadFontSizeForceSwitch",value:!1,type:"checkbox",title:this.i18n.overloadFontSizeForceSwitch,description:this.i18n.overloadFontSizeForceSwitchDesc}),this.settingUtils.addItem({key:"overloadFontSizePx",value:14,type:"slider",title:this.i18n.overloadFontSizePx,description:this.i18n.overloadFontSizePxDesc,slider:{min:5,max:60,step:1}}),this.settingUtils.addItem({key:"overloadLineHeight",value:!1,type:"checkbox",title:this.i18n.overloadLineHeight,description:this.i18n.overloadLineHeightDesc}),this.settingUtils.addItem({key:"overloadLineHeightForce",value:!1,type:"checkbox",title:this.i18n.overloadLineHeightForce,description:this.i18n.overloadLineHeightForceDesc}),this.settingUtils.addItem({key:"overloadLineHeightPx",value:28,type:"slider",title:this.i18n.overloadLineHeightPx,description:this.i18n.overloadLineHeightPxDesc,slider:{min:1,max:100,step:1}}),this.settingUtils.addItem({key:"hintDeviceSpecificSettings",value:"",type:"hint",title:this.i18n.hintDeviceSpecificSettingsTitle,description:this.i18n.hintDeviceSpecificSettingsDesc}),this.settingUtils.addItem({key:"onlyEnableListedDevices",value:!1,type:"checkbox",title:this.i18n.onlyEnableListedDevices,description:this.i18n.onlyEnableListedDevicesDesc}),this.settingUtils.addItem({key:"enableDeviceList",value:"",type:"textarea",title:this.i18n.enableDeviceList,description:this.i18n.enableDeviceListDesc}),this.settingUtils.addItem({key:"addCurrentDeviceIntoList",value:"",type:"button",title:this.i18n.addCurrentDeviceIntoList,description:this.i18n.addCurrentDeviceIntoListDesc,button:{label:this.i18n.addCurrentDeviceIntoListLabel,callback:()=>{this.appendCurrentDeviceIntoList()}}}),this.settingUtils.addItem({key:"removeCurrentDeviceFromList",value:"",type:"button",title:this.i18n.removeCurrentDeviceFromList,description:this.i18n.removeCurrentDeviceFromListDesc,button:{label:this.i18n.removeCurrentDeviceFromListLabel,callback:()=>{this.removeCurrentDeviceFromList()}}}),this.settingUtils.addItem({key:"hint",value:"",type:"hint",title:this.i18n.hintTitle,description:this.i18n.hintDesc})}onLayoutReady(){this.loadData(S),this.settingUtils.load(),(async()=>{try{const t=this.settingUtils.get("mouseHoverZeroPadding"),s=this.settingUtils.get("mainSwitch"),n=this.settingUtils.get("hideIcon"),a=this.settingUtils.get("hideIconForce"),r=this.settingUtils.get("enableAdjustStaticDoctreePadding"),l=this.settingUtils.get("Slider"),d=this.settingUtils.get("overloadFontSizeSwitch"),f=this.settingUtils.get("overloadFontSizeForceSwitch"),o=this.settingUtils.get("overloadFontSizePx"),m=this.settingUtils.get("mouseHoverZeroPaddingForce"),v=this.settingUtils.get("mouseHoverZeroPaddingPx"),h=this.settingUtils.get("mouseOverLineUnclamp"),u=this.settingUtils.get("mouseOverLineUnclampForce"),y=this.settingUtils.get("mouseOverReduceFontSize"),_=this.settingUtils.get("mouseOverLineUnclampForce"),g=this.settingUtils.get("mouseHoverReduceFontSizePx"),x=this.settingUtils.get("onlyEnableListedDevices"),D=await this.currentDeviceInList(),F=this.settingUtils.get("hideContextualLabel"),k=this.settingUtils.get("displayIconButDisableIconClick"),U=this.settingUtils.get("disable document buttons popup"),I=this.settingUtils.get("overloadLineHeight"),P=this.settingUtils.get("overloadLineHeightForce"),w=this.settingUtils.get("overloadLineHeightPx"),H=this.settingUtils.get("enableDoctreeFrontLine"),z=this.settingUtils.get("doctreeFrontLinePosition"),C=this.settingUtils.get("doctreeFrontLinePadding"),E=this.settingUtils.get("doctreeFrontLineBorder"),O=this.settingUtils.get("enableDoctreeSeperateLine"),B=this.settingUtils.get("doctreeSeperateLineBorder");if(console.log({mouseoverZeroPadding:t,mainSwitchStat:s,hideIcon:n,compressionPercentage:l,overloadFontSizeSwitch:d,mouseHoverZeroPaddingForce:m,mouseHoverZeroPaddingPx:v,mouseOverLineUnclamp:h,mouseOverLineUnclampForce:u,mouseOverReduceFontSize:y,mouseOverReduceFontSizeForce:_,mouseHoverReduceFontSizePx:g,onlyEnableListedDevices:x,currentDeviceInList:D,hideContextualLabel:F,displayIconButDIsableIconClick:k,disableDocumentButtonsPopup:U,overloadLineHeight:I,overloadLineHeightForce:P,overloadLineHeightPx:w,enableDoctreeFrontLine:H,doctreeFrontLinePosition:z,doctreeFrontLinePadding:C,doctreeFrontLineBorder:E,enableDoctreeSeperateLine:O,doctreeSeperateLineBorder:B}),(D||!x)&&s&&(I&&this.overloadLineHeight(P,w),n&&this.rmvDoctreeIcons(a),F&&this.hideContextualLabel(),t&&this.mouseOverZeroPadding(m,v),h&&this.mouseOverLineUnclamp(u),y&&this.mouseOverReduceFontSize(_,g),d&&this.overloadDoctreeFontSize(f,o),k&&this.displayIconButDIsableIconClick(),U&&this.disableDocumentButtonsPopup(),H&&!t&&!r&&this.addFrontLine(z,C,E),O&&this.addSeperateLine(B),!t&&r)){let Z=function(){document.querySelectorAll(".b3-list-item").forEach(b=>{if(!b.querySelector(".b3-list-item__toggle").getAttribute("data-compressed")){const N=parseFloat(window.getComputedStyle(b.querySelector(".b3-list-item__toggle")).paddingLeft)*(1-l/100);b.getAttribute("data-type")!="navigation-root"&&(console.dir(b.getAttribute("data-type")),b.querySelector(".b3-list-item__toggle").style.paddingLeft=`${N}px`,b.querySelector(".b3-list-item__toggle").setAttribute("data-compressed","true"))}})};const $=new MutationObserver(L=>{Z()}),T={attributes:!0,childList:!0,subtree:!0};document.querySelectorAll(".fn__flex-column").forEach(L=>{$.observe(L,T)})}}catch(t){console.error("siyuan_doctree_compress: failed inject interface",t)}})()}async onunload(){await this.settingUtils.save(),window.location.reload()}}module.exports=V;
